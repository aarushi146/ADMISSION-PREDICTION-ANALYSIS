# Predicting-chance-of-admission
Predicting whether the student has a chance of graduate admission or not based on the inputs of various exam scores using Regrssion and Classification Algorithms.
